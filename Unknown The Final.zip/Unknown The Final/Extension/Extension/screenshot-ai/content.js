let overlay = null;

function createOverlay() {
    if (document.getElementById('screenshot-ai-stealth-overlay')) {
        return document.getElementById('screenshot-ai-stealth-overlay');
    }
    const div = document.createElement('div');
    div.id = 'screenshot-ai-stealth-overlay';
    Object.assign(div.style, {
        position: 'fixed',
        bottom: '5px',
        right: '15px',
        backgroundColor: 'transparent',
        color: '#000000',
        fontSize: '11px',
        fontFamily: 'sans-serif',
        zIndex: '2147483647',
        opacity: '0',
        pointerEvents: 'none',
        textShadow: '0px 0px 2px rgba(255,255,255,0.8)',
        transition: 'opacity 0.3s'
    });
    document.body.appendChild(div);
    return div;
}

window.addEventListener('keydown', async (e) => {
    // Only trigger if Shift + Z is pressed exactly
    if (e.shiftKey && e.key.toLowerCase() === 'z') {
        
        overlay = createOverlay();
        overlay.style.opacity = '1';
        overlay.textContent = "Darshan University";
        
        try {
            if (!chrome?.runtime?.id) {
                throw new Error("Extension reloaded. Please refresh page.");
            }
            
            // 1. Request tab capture from background service worker
            chrome.runtime.sendMessage({ action: 'capture_tab' }, async (response) => {
                if (chrome.runtime.lastError) {
                    showError(chrome.runtime.lastError.message);
                    return;
                }
                
                if (response?.error || !response?.dataUrl) {
                    showError(response?.error || "Capture failed");
                    return;
                }
                
                try {
                    const prompt = "You are a master academic exam solver with 100% precision. Carefully analyze the image, question text, formulas, diagrams, and all choices/options (A, B, C, D). Solve step-by-step internally, double-checking all calculations and logic to guarantee 100% accuracy. Output ONLY the final correct option letter and answer text (e.g. 'A) 42'). If multiple questions appear, put each answer on a new line. Do not include extra conversational text.";
                    
                    // 2. Dynamically import gemini.js in tab context
                    const geminiUrl = chrome.runtime.getURL('gemini.js');
                    const { analyzeScreenshot } = await import(geminiUrl);
                    
                    // 3. Execute fetch in main browser tab network stack
                    const result = await analyzeScreenshot(response.dataUrl, prompt);
                    const lines = result.text.split('\n').map(l => l.trim().replace(/[\*\_]/g, '')).filter(l => l);
                    
                    if (lines.length > 0) {
                        const maxRequests = result.activeKeysCount * 1500;
                        const percentUsed = ((result.totalUsageCount / maxRequests) * 100).toFixed(2);
                        lines.push(`Quota Used: ${percentUsed}%`);
                        showAnswers(lines);
                    } else {
                        showError("Gemini returned blank answer.");
                    }
                } catch (err) {
                    console.error("Gemini Analysis Error:", err);
                    showError(err.message ? err.message.substring(0, 90) : "Analysis Error");
                }
            });
        } catch (err) {
            console.error("Extension Context Error:", err);
            showError("Please refresh page");
        }
    }
});

function showAnswers(answers) {
    if (!overlay) overlay = createOverlay();
    
    let i = 0;
    function showNext() {
        if (i >= answers.length) {
            overlay.style.opacity = '0';
            setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 300);
            return;
        }
        overlay.textContent = answers[i];
        overlay.style.opacity = '1';
        
        setTimeout(() => {
            overlay.style.opacity = '0';
            setTimeout(() => {
                i++;
                showNext();
            }, 400); 
        }, 2500); 
    }
    
    overlay.style.opacity = '0';
    setTimeout(showNext, 300);
}

function showError(text) {
    if (!overlay) overlay = createOverlay();
    overlay.textContent = text;
    overlay.style.opacity = '1';
    setTimeout(() => {
        overlay.style.opacity = '0';
        setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 300);
    }, 2500);
}
