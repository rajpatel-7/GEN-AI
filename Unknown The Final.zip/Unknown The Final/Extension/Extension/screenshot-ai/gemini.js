import { getApiKeys } from './storage.js';

export async function analyzeScreenshot(dataUrl, prompt) {
    const keys = await getApiKeys();
    if (!keys || keys.length === 0) {
        throw new Error('No valid API key found. Please open Extension Settings and paste your Gemini API key.');
    }

    const match = dataUrl.match(/^data:(image\/(?:png|jpeg));base64,(.+)$/);
    if (!match) throw new Error('Invalid capture data format');
    
    const mimeType = match[1];
    const base64Data = match[2];

    const payload = {
        contents: [{
            parts: [
                { text: prompt },
                {
                    inlineData: {
                        mimeType: mimeType,
                        data: base64Data
                    }
                }
            ]
        }],
        generationConfig: {
            temperature: 0.0,
            topP: 0.95
        }
    };

    const targetModel = 'gemini-3.6-flash';
    let lastError = null;

    for (let i = 0; i < keys.length; i++) {
        const apiKey = keys[i];
        if (!apiKey || apiKey.includes('SECOND_API_KEY')) continue;

        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
        
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();

            if (!response.ok) {
                lastError = data.error?.message || response.statusText || `${targetModel} request failed`;
                console.warn(`Key ${i} (${apiKey.substring(0, 12)}...) failed:`, lastError);
                continue; // Move to next key if this key is revoked (403) or unavailable (503)
            }

            const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (!candidateText) {
                lastError = data.candidates?.[0]?.finishReason 
                    ? `Model stopped: ${data.candidates[0].finishReason}`
                    : 'Empty response from model';
                continue;
            }

            // Successfully fetched data. Track usage.
            const stats = await chrome.storage.local.get(['dailyQuota']);
            const todayDate = new Date().toDateString();
            let usage = stats.dailyQuota || { date: todayDate, count: 0 };
            
            if (usage.date !== todayDate) { 
                usage = { date: todayDate, count: 0 }; 
            }
            usage.count++;
            await chrome.storage.local.set({ dailyQuota: usage });

            return {
                text: candidateText,
                totalUsageCount: usage.count,
                activeKeysCount: keys.length
            };

        } catch (err) {
            console.error(`Fetch error on Key ${i}:`, err);
            if (typeof navigator !== 'undefined' && !navigator.onLine) {
                lastError = "Offline: Please check your internet connection.";
            } else if (err.message === 'Failed to fetch') {
                lastError = "Connection Blocked: Unable to reach Google Gemini API (generativelanguage.googleapis.com). Please check if an AdBlocker, Firewall, or VPN is blocking requests.";
            } else {
                lastError = err.message || "Network Error";
            }
        }
    }

    throw new Error(lastError || 'All API Keys failed or returned quota errors.');
}
