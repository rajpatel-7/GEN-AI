export async function getApiKeys() {
  const result = await chrome.storage.local.get(['geminiApiKeys']);
  const defaultKeys = [

  ];

  const stored = Array.isArray(result.geminiApiKeys) ? result.geminiApiKeys : [];
  const allCandidates = [...stored, ...defaultKeys];

  const validKeys = allCandidates
    .map(k => typeof k === 'string' ? k.replace(/^["']|["']$/g, '').trim() : '')
    .filter(k => k.length > 10 && !k.includes('SECOND_API_KEY'));

  return Array.from(new Set(validKeys));
}

export async function setApiKeys(keysArray) {
  await chrome.storage.local.set({ geminiApiKeys: keysArray });
}

export async function getApiKey() {
  const keys = await getApiKeys();
  return keys[0] || '';
}

export async function setApiKey(key) {
  const keys = key.includes(',') ? key.split(',').map(k => k.trim()).filter(Boolean) : [key.trim()];
  await setApiKeys(keys);
}
