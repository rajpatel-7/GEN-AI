chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'capture_tab') {
        const windowId = sender?.tab?.windowId;
        
        chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 100 }, (dataUrl) => {
            if (chrome.runtime.lastError || !dataUrl) {
                sendResponse({ error: chrome.runtime.lastError?.message || "Screen capture returned empty." });
            } else {
                sendResponse({ dataUrl: dataUrl });
            }
        });
        return true; // Keep channel open for async response
    }
});
