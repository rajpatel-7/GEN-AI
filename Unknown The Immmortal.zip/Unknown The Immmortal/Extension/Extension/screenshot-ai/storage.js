export async function getApiKeys() {
  const result = await chrome.storage.local.get(['geminiApiKeys']);
  const defaultKeys = [

  ];

  const stored = Array.isArray(result.geminiApiKeys) ? result.geminiApiKeys : [];
  const allCandidates = [...stored, ...defaultKeys];

  const validKeys = allCandidates
    .map(k => typeof k === 'string' ? k.replace(/^["']|["']$/g, '').trim() : '')
    .filter(k => k.length > 10 && !k.includes('SECOND_API_KEY'));

  return Array.from(new Set(validKeys));
}

export async function setApiKeys(keysArray) {
  const valid = (Array.isArray(keysArray) ? keysArray : [])
    .map(k => typeof k === 'string' ? k.replace(/^["']|["']$/g, '').trim() : '')
    .filter(k => k.length > 10 && !k.includes('SECOND_API_KEY'));
  await chrome.storage.local.set({ geminiApiKeys: Array.from(new Set(valid)) });
}

export async function getApiKey() {
  const keys = await getApiKeys();
  return keys[0] || '';
}

export async function setApiKey(key) {
  if (Array.isArray(key)) {
    await setApiKeys(key);
  } else if (typeof key === 'string') {
    const keys = key.split(/[\n,]/).map(k => k.trim()).filter(Boolean);
    await setApiKeys(keys);
  }
}

// Groq Free Backup API Keys
export async function getGroqApiKeys() {
  const result = await chrome.storage.local.get(['groqApiKeys']);
  const defaultGroqKeys = [
    "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"
  ];

  const stored = Array.isArray(result.groqApiKeys) ? result.groqApiKeys : [];
  const allCandidates = [...stored, ...defaultGroqKeys];

  const validKeys = allCandidates
    .map(k => typeof k === 'string' ? k.trim() : '')
    .filter(k => k.length > 15 && k.startsWith('gsk_'));

  return Array.from(new Set(validKeys));
}

export async function setGroqApiKeys(keysArray) {
  const valid = (Array.isArray(keysArray) ? keysArray : [])
    .map(k => typeof k === 'string' ? k.trim() : '')
    .filter(k => k.length > 15 && k.startsWith('gsk_'));
  await chrome.storage.local.set({ groqApiKeys: Array.from(new Set(valid)) });
}

export async function getExamSettings() {
  const result = await chrome.storage.local.get(['examUrl', 'userTitle', 'customLogo']);
  return {
    examUrl: result.examUrl || 'https://darshanums.in/Login.aspx',
    userTitle: result.userTitle || 'You are logged in as Generic Demo',
    customLogo: result.customLogo || ''
  };
}

export async function setExamSettings(settings) {
  const toSave = {};
  if (settings.examUrl !== undefined) toSave.examUrl = settings.examUrl;
  if (settings.userTitle !== undefined) toSave.userTitle = settings.userTitle;
  if (settings.customLogo !== undefined) toSave.customLogo = settings.customLogo;
  await chrome.storage.local.set(toSave);
}
