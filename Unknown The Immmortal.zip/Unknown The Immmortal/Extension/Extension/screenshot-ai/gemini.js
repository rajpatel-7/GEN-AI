import { getApiKeys, getGroqApiKeys } from './storage.js';

// Cascading Google Gemini models: tries 3.6-flash first, then cascades to 2.0-flash, 1.5-flash, etc.
const GEMINI_MODELS = [
    'gemini-3.6-flash',
    'gemini-2.0-flash',
    'gemini-1.5-flash',
    'gemini-2.0-flash-lite'
];

async function callGroqVision(dataUrl, prompt, groqKeys) {
    if (!groqKeys || groqKeys.length === 0) return null;

    const groqModels = ['llama-3.2-11b-vision-preview', 'llama-3.2-90b-vision-preview'];

    for (const key of groqKeys) {
        for (const model of groqModels) {
            try {
                const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${key}`
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [
                            {
                                role: 'user',
                                content: [
                                    { type: 'text', text: prompt },
                                    {
                                        type: 'image_url',
                                        image_url: { url: dataUrl }
                                    }
                                ]
                            }
                        ],
                        temperature: 0.0,
                        max_tokens: 512
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    const text = data.choices?.[0]?.message?.content;
                    if (text && text.trim()) {
                        return {
                            text: text.trim(),
                            model: model.includes('90b') ? 'Groq 90B' : 'Groq Vision'
                        };
                    }
                } else {
                    console.warn(`Groq (${model}) returned status ${response.status}`);
                }
            } catch (err) {
                console.warn(`Groq fetch error (${model}):`, err);
            }
        }
    }
    return null;
}

export async function analyzeScreenshot(dataUrl, prompt) {
    const keys = await getApiKeys();
    const groqKeys = await getGroqApiKeys();

    if ((!keys || keys.length === 0) && (!groqKeys || groqKeys.length === 0)) {
        throw new Error('No valid API key found. Please open Extension Settings and paste your Gemini or Groq key.');
    }

    const match = dataUrl.match(/^data:(image\/(?:png|jpeg));base64,(.+)$/);
    if (!match) throw new Error('Invalid capture data format');
    
    const mimeType = match[1];
    const base64Data = match[2];

    const payload = {
        contents: [{
            parts: [
                { text: prompt },
                {
                    inlineData: {
                        mimeType: mimeType,
                        data: base64Data
                    }
                }
            ]
        }],
        generationConfig: {
            temperature: 0.0,
            topP: 0.95
        }
    };

    let lastError = null;

    // Load last used key index for Round-Robin rotation across all Gemini keys
    const state = await chrome.storage.local.get(['lastKeyIndex']);
    const totalKeys = keys.length;
    let nextIndex = typeof state.lastKeyIndex === 'number' ? (state.lastKeyIndex + 1) % totalKeys : 0;

    // 1. Try Google Gemini with model cascade and key rotation
    if (totalKeys > 0) {
        for (let attempt = 0; attempt < totalKeys; attempt++) {
            const keyIndex = (nextIndex + attempt) % totalKeys;
            const apiKey = keys[keyIndex];
            
            if (!apiKey || apiKey.includes('SECOND_API_KEY')) continue;

            // Try each model in the cascade (2.0-flash -> 1.5-flash -> 2.0-flash-lite)
            for (const model of GEMINI_MODELS) {
                const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
                
                try {
                    const response = await fetch(endpoint, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    });

                    const data = await response.json();

                    if (!response.ok) {
                        lastError = data.error?.message || response.statusText || `${model} request failed`;
                        console.warn(`Gemini (${model}) on Key #${keyIndex + 1} failed:`, lastError);
                        // If model is busy, overloaded (503/429), cascade immediately to next model!
                        continue;
                    }

                    const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
                    if (!candidateText) {
                        lastError = data.candidates?.[0]?.finishReason 
                            ? `Model stopped: ${data.candidates[0].finishReason}`
                            : 'Empty response from model';
                        continue;
                    }

                    // Save the successfully used key index for next round-robin request
                    await chrome.storage.local.set({ lastKeyIndex: keyIndex });

                    // Successfully fetched data. Track usage.
                    const stats = await chrome.storage.local.get(['dailyQuota']);
                    const todayDate = new Date().toDateString();
                    let usage = stats.dailyQuota || { date: todayDate, count: 0 };
                    
                    if (usage.date !== todayDate) { 
                        usage = { date: todayDate, count: 0 }; 
                    }
                    usage.count++;
                    await chrome.storage.local.set({ dailyQuota: usage });

                    return {
                        text: candidateText,
                        provider: model === 'gemini-2.0-flash' ? 'Gemini 2.0' : `Gemini (${model.replace('gemini-', '')})`,
                        totalUsageCount: usage.count,
                        activeKeysCount: totalKeys,
                        usedKeyIndex: keyIndex + 1
                    };

                } catch (err) {
                    console.error(`Fetch error on Gemini ${model} Key #${keyIndex + 1}:`, err);
                    if (typeof navigator !== 'undefined' && !navigator.onLine) {
                        lastError = "Offline: Please check your internet connection.";
                    } else {
                        lastError = err.message || "Network Error";
                    }
                }
            }
        }
    }

    // 2. Level 2 Failover: If Gemini models are all overloaded, switch to Groq Vision AI!
    if (groqKeys && groqKeys.length > 0) {
        console.warn("All Gemini models busy. Activating Groq Vision AI fallback...");
        const groqResult = await callGroqVision(dataUrl, prompt, groqKeys);
        if (groqResult) {
            return {
                text: groqResult.text,
                provider: groqResult.model,
                totalUsageCount: 1,
                activeKeysCount: groqKeys.length,
                usedKeyIndex: 1
            };
        }
    }

    throw new Error(lastError || 'All AI models are currently busy. Please try again in a few seconds.');
}
