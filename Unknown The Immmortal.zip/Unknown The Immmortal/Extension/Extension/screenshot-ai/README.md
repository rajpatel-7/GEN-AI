# Safe Exam Browser (MSEB) & Screenshot AI

A powerful Google Chrome Extension (Manifest V3) combining:
1. **Safe Exam Browser (MSEB) Fullscreen Simulation**: Opens an exam link in automatic full screen with authentic iPad status bar, `mseb` header, and footer controls.
2. **Quit Session Dialog & Stealth Close**: Replicates the exact iOS/SEB quit prompt. Clicking "Quit" immediately displays a full-screen loading veil (blocking tabs from flashing) and terminates Google Chrome in the background.
3. **AI Exam Solver**: Press `Ctrl+Z` or `Shift+Z` to solve multiple-choice academic questions with Gemini AI in stealth mode.

---

## 🚀 Features

### 1. Safe Exam Browser (MSEB) Simulation
- **Auto Fullscreen Launch**: Enter your exam link in the extension popup and click **🚀 Launch Fullscreen Exam**. The link opens in true fullscreen without Chrome address bars or tabs.
- **Authentic Top Header**:
  - iPad status bar with real-time clock, Bluetooth icon, battery percentage (`78%`), and battery graphic.
  - Silver-grey `mseb` header with left title and right status (`You are logged in as Generic Demo` or custom student name).
- **Authentic Footer**:
  - Left slot for your custom logo (leave empty or configure via Settings).
  - Right reload button (`⟳`) to refresh the exam.
  - Right quit/power button (`⏻`) to trigger the quit dialog.
- **Isolated Shadow DOM**: The header, footer, and modals are rendered inside a Shadow Root, ensuring zero CSS conflicts with any exam portal.

### 2. Exit Modal & Background Close with Loading Screen
- Clicking the footer quit button displays the modal:
  - **Quit Session**
  - *"Are you sure you want to quit this session?"*
  - **Cancel** / **Quit**
- On clicking **Quit**:
  - A clean fullscreen loading overlay (*"Closing session..."*) immediately covers the entire screen, preventing any other browser tabs or desktop from showing.
  - Background service worker closes all Chrome windows, cleanly shutting down Chrome without tab transitions.

### 3. Screenshot AI Solver (Ctrl+Z / Shift+Z)
- Press `Ctrl + Z` or `Shift + Z` on any page to capture the screen and solve the question with Gemini Vision AI.
- Displays stealth overlay ("Darshan University") that crossfades into answers and quota usage.
- Also triggerable from the popup button: **📸 Capture & Solve Screen**.

---

## 🛠️ Installation & Setup

1. Open Google Chrome and go to `chrome://extensions`.
2. Toggle **Developer mode** in the top right.
3. Click **Load unpacked** and select the folder:
   `Unknown The Final\Extension\Extension\screenshot-ai`
4. Click the extension icon in Chrome's toolbar to open the popup.

---

## ⚙️ Configuration (Settings)

Access settings by clicking **⚙️ Settings** in the popup or right-clicking the extension icon and choosing **Options**:
- **Default Exam Link**: Set your portal link to avoid re-typing every time.
- **User Display Title**: Customize the top-right header text (e.g., `You are logged in as Student Name`).
- **Custom Footer Logo**: Paste an image URL or base64 data to place your logo in the bottom-left slot. Leave empty for no logo.
- **Gemini API Key**: Paste your Google AI Studio Gemini API key to enable AI solving.
