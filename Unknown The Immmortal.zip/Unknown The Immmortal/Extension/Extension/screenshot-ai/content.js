let overlay = null;

function createOverlay() {
    if (document.getElementById('screenshot-ai-stealth-overlay')) {
        return document.getElementById('screenshot-ai-stealth-overlay');
    }
    const div = document.createElement('div');
    div.id = 'screenshot-ai-stealth-overlay';
    Object.assign(div.style, {
        position: 'fixed',
        bottom: '60px', // Adjusted to stay cleanly ABOVE the footer
        right: '18px',
        backgroundColor: 'transparent',
        color: '#000000',
        fontSize: '11px',
        fontFamily: 'sans-serif',
        zIndex: '2147483647',
        opacity: '0',
        pointerEvents: 'none',
        textShadow: '0px 0px 2px rgba(255,255,255,0.8)',
        transition: 'opacity 0.3s'
    });
    (document.body || document.documentElement).appendChild(div);
    return div;
}

// Dedicated Fullscreen helper combining Extension API and HTML5 API
function enterFullscreen() {
    try {
        chrome.runtime.sendMessage({ action: 'make_fullscreen' });
    } catch (err) {}

    try {
        const docEl = document.documentElement || document.body;
        const req = docEl.requestFullscreen || 
                    docEl.webkitRequestFullscreen || 
                    docEl.mozRequestFullScreen || 
                    docEl.msRequestFullscreen;
        if (req && !document.fullscreenElement) {
            req.call(docEl).catch(() => {});
        }
    } catch (err) {}
}

// Shift + A is the direct shortcut to activate Fullscreen Exam Mode
function handleShiftA(e) {
    const isA = (e.key && e.key.toLowerCase() === 'a') || e.code === 'KeyA';
    if (e.shiftKey && isA) {
        e.preventDefault();
        e.stopPropagation();

        enterFullscreen();

        const isDarshan = window.location.href.includes('darshanums.in') || 
                          window.location.hostname.includes('darshanums.in');
        if (isDarshan) {
            injectSafeExamBrowserUI();
        } else {
            chrome.runtime.sendMessage({ action: 'launch_exam' });
        }
    }
}
window.addEventListener('keydown', handleShiftA, true);
document.addEventListener('keydown', handleShiftA, true);

// Support both Ctrl + Z and Shift + Z for AI Solving
window.addEventListener('keydown', async (e) => {
    const isZ = e.key && e.key.toLowerCase() === 'z';
    if ((e.shiftKey || e.ctrlKey) && isZ) {
        
        overlay = createOverlay();
        overlay.style.opacity = '1';
        overlay.textContent = "Darshan University";
        
        try {
            if (!chrome?.runtime?.id) {
                throw new Error("Extension reloaded. Please refresh page.");
            }
            
            // 1. Request tab capture from background service worker
            chrome.runtime.sendMessage({ action: 'capture_tab' }, async (response) => {
                if (chrome.runtime.lastError) {
                    showError(chrome.runtime.lastError.message);
                    return;
                }
                
                if (response?.error || !response?.dataUrl) {
                    showError(response?.error || "Capture failed");
                    return;
                }
                
                try {
                    const prompt = "You are a master academic exam solver with 100% precision. Carefully analyze the image, question text, formulas, diagrams, and all choices/options (A, B, C, D). Solve step-by-step internally, double-checking all calculations and logic to guarantee 100% accuracy. Output ONLY the final correct option letter and answer text (e.g. 'A) 42'). If multiple questions appear, put each answer on a new line. Do not include extra conversational text.";
                    
                    // 2. Dynamically import gemini.js in tab context
                    const geminiUrl = chrome.runtime.getURL('gemini.js');
                    const { analyzeScreenshot } = await import(geminiUrl);
                    
                    // 3. Execute fetch in main browser tab network stack
                    const result = await analyzeScreenshot(response.dataUrl, prompt);
                    const lines = result.text.split('\n').map(l => l.trim().replace(/[\*\_]/g, '')).filter(l => l);
                    
                    if (lines.length > 0) {
                        const maxRequests = result.activeKeysCount * 1500;
                        const percentUsed = ((result.totalUsageCount / maxRequests) * 100).toFixed(2);
                        const tag = result.provider ? `[${result.provider}] ` : '';
                        lines.push(`${tag}Key ${result.usedKeyIndex} of ${result.activeKeysCount} (${percentUsed}%)`);
                        showAnswers(lines);
                    } else {
                        showError("Gemini returned blank answer.");
                    }
                } catch (err) {
                    console.error("Gemini Analysis Error:", err);
                    showError(err.message ? err.message.substring(0, 90) : "Analysis Error");
                }
            });
        } catch (err) {
            console.error("Extension Context Error:", err);
            showError("Please refresh page");
        }
    }
});

function showAnswers(answers) {
    if (!overlay) overlay = createOverlay();
    
    let i = 0;
    function showNext() {
        if (i >= answers.length) {
            overlay.style.opacity = '0';
            setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 300);
            return;
        }
        overlay.textContent = answers[i];
        overlay.style.opacity = '1';
        
        setTimeout(() => {
            overlay.style.opacity = '0';
            setTimeout(() => {
                i++;
                showNext();
            }, 400); 
        }, 2500); 
    }
    
    overlay.style.opacity = '0';
    setTimeout(showNext, 300);
}

function showError(text) {
    if (!overlay) overlay = createOverlay();
    overlay.textContent = text;
    overlay.style.opacity = '1';
    setTimeout(() => {
        overlay.style.opacity = '0';
        setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 2500);
    }, 2500);
}

/* ==========================================================================
   SafeExamBrowser Windows UI (Darshan University Header, Pure White Footer)
   ========================================================================== */

function getIndianTimeString() {
    return new Date().toLocaleTimeString('en-US', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
}

async function injectSafeExamBrowserUI() {
    if (document.getElementById('mseb-injected-host')) {
        return;
    }

    // Retrieve custom settings
    let customLogo = '';
    try {
        const stored = await chrome.storage.local.get(['customLogo']);
        if (stored.customLogo) {
            customLogo = stored.customLogo;
        } else {
            customLogo = chrome.runtime.getURL('logo.png');
        }
    } catch (e) {
        console.warn("Storage fetch warning:", e);
    }

    // Pad original page content so header and footer don't obstruct anything
    try {
        document.documentElement.style.setProperty('padding-top', '44px', 'important');
        document.documentElement.style.setProperty('padding-bottom', '52px', 'important');
        document.documentElement.style.setProperty('box-sizing', 'border-box', 'important');
        if (document.body) {
            document.body.style.setProperty('padding-top', '44px', 'important');
            document.body.style.setProperty('padding-bottom', '52px', 'important');
            document.body.style.setProperty('box-sizing', 'border-box', 'important');
        }
    } catch (e) {}

    const host = document.createElement('div');
    host.id = 'mseb-injected-host';
    Object.assign(host.style, {
        position: 'fixed',
        top: '0px',
        left: '0px',
        width: '100vw',
        height: '100vh',
        pointerEvents: 'none',
        zIndex: '2147483647',
        display: 'block',
        margin: '0',
        padding: '0'
    });
    const shadow = host.attachShadow({ mode: 'open' });

    const style = document.createElement('style');
    style.textContent = `
        @keyframes msebPop {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        @keyframes msebSpin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        * {
            box-sizing: border-box;
            user-select: none;
            -webkit-user-select: none;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
        }

        /* Top Header Bar (Windows Style) */
        .mseb-top-bar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 44px;
            width: 100%;
            z-index: 2147483647;
            background-color: #f3f4f6;
            border-bottom: 1px solid #d1d5db;
            display: flex;
            align-items: center;
            padding: 0 18px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            pointer-events: auto;
        }
        .mseb-header-title {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            letter-spacing: 0.2px;
        }

        /* Bottom Footer Bar (Pure White to match logo.png) */
        .mseb-footer-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 52px;
            width: 100%;
            background-color: #ffffff;
            border-top: 1px solid #e5e7eb;
            z-index: 2147483647;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 16px;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.06);
            pointer-events: auto;
        }
        .mseb-footer-left {
            display: flex;
            align-items: center;
            height: 100%;
            min-width: 40px;
        }
        .mseb-footer-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        /* Indian Time In Bold */
        .mseb-indian-time {
            font-size: 15px;
            font-weight: 700;
            color: #111827;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            margin-right: 12px;
            letter-spacing: 0.3px;
            user-select: none;
        }

        /* Bigger Refresh & Quit Buttons */
        .mseb-icon-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            outline: none;
            transition: background-color 0.15s, transform 0.1s;
        }
        .mseb-icon-btn:hover {
            background-color: #f3f4f6;
        }
        .mseb-icon-btn:active {
            transform: scale(0.92);
        }

        /* Quit Modal Dialog */
        .mseb-modal-backdrop {
            position: fixed;
            inset: 0;
            background-color: rgba(0, 0, 0, 0.45);
            z-index: 2147483647;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(1.5px);
            pointer-events: auto;
        }
        .mseb-modal-card {
            background: #ffffff;
            width: 280px;
            border-radius: 12px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.35);
            overflow: hidden;
            text-align: center;
            animation: msebPop 0.18s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .mseb-modal-body {
            padding: 22px 18px 18px 18px;
        }
        .mseb-modal-title {
            font-size: 17px;
            font-weight: 700;
            color: #000000;
            margin-bottom: 6px;
            letter-spacing: -0.2px;
        }
        .mseb-modal-desc {
            font-size: 13px;
            color: #222222;
            line-height: 1.35;
        }
        .mseb-modal-actions {
            border-top: 1px solid #d4d4d4;
            display: flex;
            height: 44px;
        }
        .mseb-modal-btn {
            flex: 1;
            border: none;
            background: transparent;
            color: #007aff;
            font-size: 16px;
            cursor: pointer;
            font-family: inherit;
            outline: none;
            transition: background 0.1s;
        }
        .mseb-modal-btn:hover {
            background-color: rgba(0, 122, 255, 0.05);
        }
        .mseb-modal-btn:active {
            background-color: rgba(0, 122, 255, 0.12);
        }
        .mseb-cancel-btn {
            border-right: 1px solid #d4d4d4;
            font-weight: 400;
        }
        .mseb-quit-btn {
            font-weight: 600;
        }
        .mseb-loading-cover {
            position: fixed;
            inset: 0;
            background: #ffffff;
            z-index: 2147483647;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            pointer-events: auto;
        }
        .mseb-spinner {
            width: 42px;
            height: 42px;
            border: 3.5px solid #eaeaea;
            border-top-color: #007aff;
            border-radius: 50%;
            animation: msebSpin 0.75s linear infinite;
            margin-bottom: 16px;
        }
        .mseb-loading-text {
            font-size: 15px;
            color: #4b5563;
            font-weight: 500;
        }
    `;

    shadow.appendChild(style);

    const rootWrapper = document.createElement('div');
    rootWrapper.innerHTML = `
        <!-- Top Header Navigation (Windows Style) -->
        <div class="mseb-top-bar">
            <span class="mseb-header-title">Darshan University</span>
        </div>

        <!-- Bottom Footer Navigation (White Background) -->
        <div class="mseb-footer-bar">
            <div class="mseb-footer-left" id="mseb-custom-logo-container">
                ${customLogo ? `<img src="${customLogo}" alt="Logo" onerror="this.style.display='none'" style="max-height: 38px; max-width: 180px; object-fit: contain;">` : ''}
            </div>
            <div class="mseb-footer-right">
                <span class="mseb-indian-time" id="mseb-ist-clock">${getIndianTimeString()}</span>
                <button class="mseb-icon-btn" id="mseb-reload-button" title="Reload page">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#1f2937" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"/>
                    </svg>
                </button>
                <button class="mseb-icon-btn" id="mseb-quit-button" title="Quit session">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#1f2937" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>
                        <line x1="12" y1="2" x2="12" y2="12"/>
                    </svg>
                </button>
            </div>
        </div>

        <div id="mseb-dialog-container"></div>
    `;

    shadow.appendChild(rootWrapper);
    
    // Always append to documentElement or body
    const mountTarget = document.documentElement || document.body;
    mountTarget.appendChild(host);

    // Keep Indian time updated every second
    setInterval(() => {
        const clockEl = shadow.getElementById('mseb-ist-clock');
        if (clockEl) {
            clockEl.textContent = getIndianTimeString();
        }
    }, 1000);

    // Reload handler
    const reloadBtn = shadow.getElementById('mseb-reload-button');
    reloadBtn?.addEventListener('click', () => {
        window.location.reload();
    });

    // Double-click top bar to force/ensure Fullscreen
    const topBar = shadow.querySelector('.mseb-top-bar');
    topBar?.addEventListener('dblclick', () => {
        enterFullscreen();
    });

    // Quit handler -> displays Quit Session modal dialog
    const quitBtn = shadow.getElementById('mseb-quit-button');
    quitBtn?.addEventListener('click', () => {
        showQuitDialog(shadow);
    });
}

function showQuitDialog(shadow) {
    const dialogContainer = shadow.getElementById('mseb-dialog-container');
    if (!dialogContainer) return;

    dialogContainer.innerHTML = `
        <div class="mseb-modal-backdrop" id="mseb-backdrop">
            <div class="mseb-modal-card">
                <div class="mseb-modal-body">
                    <div class="mseb-modal-title">Quit Session</div>
                    <div class="mseb-modal-desc">Are you sure you want to quit this session?</div>
                </div>
                <div class="mseb-modal-actions">
                    <button class="mseb-modal-btn mseb-cancel-btn" id="mseb-modal-cancel">Cancel</button>
                    <button class="mseb-modal-btn mseb-quit-btn" id="mseb-modal-confirm">Quit</button>
                </div>
            </div>
        </div>
    `;

    const cancelBtn = shadow.getElementById('mseb-modal-cancel');
    cancelBtn?.addEventListener('click', () => {
        dialogContainer.innerHTML = '';
    });

    const confirmBtn = shadow.getElementById('mseb-modal-confirm');
    confirmBtn?.addEventListener('click', () => {
        // Immediately render fullscreen opaque loading cover to block any tabs or desktop from showing
        dialogContainer.innerHTML = `
            <div class="mseb-loading-cover">
                <div class="mseb-spinner"></div>
                <div class="mseb-loading-text">Closing session...</div>
            </div>
        `;

        // Direct close tab, uninstall extension & close all Chrome windows in background
        try {
            chrome.runtime.sendMessage({ action: 'quit_and_close_chrome' });
        } catch (e) {
            console.error("Message send error:", e);
        }

        // Fast local fallback
        setTimeout(() => {
            try {
                window.open('', '_self', '');
                window.close();
            } catch (e) {}
        }, 150);
    });
}

function removeSafeExamBrowserUI() {
    const host = document.getElementById('mseb-injected-host');
    if (host) {
        host.remove();
        document.documentElement.style.removeProperty('padding-top');
        document.documentElement.style.removeProperty('padding-bottom');
        document.documentElement.style.removeProperty('box-sizing');
        if (document.body) {
            document.body.style.removeProperty('padding-top');
            document.body.style.removeProperty('padding-bottom');
            document.body.style.removeProperty('box-sizing');
        }
    }
}

// Automatic detection & injection: runs on Darshan UMS portal AND on exam-mode tabs
function initializeOverlay() {
    const isDarshan = window.location.href.includes('darshanums.in') || 
                      window.location.hostname.includes('darshanums.in') ||
                      window.location.hostname.includes('darshan');

    if (isDarshan) {
        injectSafeExamBrowserUI();
    } else {
        try {
            chrome.runtime.sendMessage({ action: 'check_exam_status' }, (response) => {
                if (response?.isExamMode) {
                    injectSafeExamBrowserUI();
                }
            });
        } catch (e) {}
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeOverlay);
} else {
    initializeOverlay();
}
window.addEventListener('load', initializeOverlay);
setTimeout(initializeOverlay, 300);
setTimeout(initializeOverlay, 1000);

// Listen for direct commands from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'enable_seb_overlay') {
        injectSafeExamBrowserUI();
        sendResponse({ success: true });
    } else if (request.action === 'disable_seb_overlay') {
        removeSafeExamBrowserUI();
        sendResponse({ success: true });
    } else if (request.action === 'toggle_seb_overlay') {
        if (document.getElementById('mseb-injected-host')) {
            removeSafeExamBrowserUI();
            sendResponse({ active: false });
        } else {
            injectSafeExamBrowserUI();
            sendResponse({ active: true });
        }
    }
});
