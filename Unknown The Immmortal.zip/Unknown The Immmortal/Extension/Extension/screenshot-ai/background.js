const examWindowIds = new Set();
const examTabIds = new Set();

chrome.tabs.onCreated.addListener((tab) => {
    if (examWindowIds.has(tab.windowId)) {
        examTabIds.add(tab.id);
    }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (examWindowIds.has(tab.windowId)) {
        examTabIds.add(tabId);
    }
});

chrome.windows.onRemoved.addListener((windowId) => {
    examWindowIds.delete(windowId);
});

chrome.tabs.onRemoved.addListener((tabId) => {
    examTabIds.delete(tabId);
});

function launchExamSession(callback) {
    const targetUrl = 'https://darshanums.in/Login.aspx';
    chrome.windows.create({
        url: targetUrl,
        state: 'fullscreen',
        focused: true
    }, (win) => {
        if (win?.id) {
            examWindowIds.add(win.id);
            if (win.tabs && win.tabs.length > 0) {
                examTabIds.add(win.tabs[0].id);
            }
        }
        if (callback) callback({ success: true, windowId: win?.id });
    });
}

// Clicking the extension icon in the Chrome toolbar directly toggles/launches fullscreen
if (chrome.action?.onClicked) {
    chrome.action.onClicked.addListener((tab) => {
        if (tab?.windowId) {
            chrome.windows.update(tab.windowId, { state: 'fullscreen' });
            examWindowIds.add(tab.windowId);
            if (tab.id) {
                examTabIds.add(tab.id);
                chrome.tabs.sendMessage(tab.id, { action: 'enable_seb_overlay' });
            }
        }
        if (!tab?.url?.includes('darshanums.in')) {
            launchExamSession();
        }
    });
}

// Global Chrome shortcut command (Ctrl+Shift+A)
if (chrome.commands?.onCommand) {
    chrome.commands.onCommand.addListener((command) => {
        if (command === 'launch_exam_cmd') {
            launchExamSession();
        }
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'capture_tab') {
        const windowId = sender?.tab?.windowId;
        
        chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 100 }, (dataUrl) => {
            if (chrome.runtime.lastError || !dataUrl) {
                sendResponse({ error: chrome.runtime.lastError?.message || "Screen capture returned empty." });
            } else {
                sendResponse({ dataUrl: dataUrl });
            }
        });
        return true; // Keep channel open for async response
    }

    if (message.action === 'make_fullscreen') {
        const winId = sender?.tab?.windowId;
        const setFullscreen = (targetWinId) => {
            if (targetWinId) {
                chrome.windows.update(targetWinId, { state: 'fullscreen', focused: true }, (w) => {
                    if (chrome.runtime.lastError) {
                        console.warn("Fullscreen update error:", chrome.runtime.lastError.message);
                    }
                });
                examWindowIds.add(targetWinId);
                if (sender?.tab?.id) examTabIds.add(sender.tab.id);
            }
        };

        if (winId) {
            setFullscreen(winId);
        } else {
            chrome.windows.getLastFocused({ populate: false }, (lastWin) => {
                if (lastWin?.id) {
                    setFullscreen(lastWin.id);
                } else {
                    chrome.windows.getCurrent((currWin) => {
                        if (currWin?.id) setFullscreen(currWin.id);
                    });
                }
            });
        }
        sendResponse({ success: true });
        return true;
    }

    if (message.action === 'launch_exam') {
        launchExamSession((res) => sendResponse(res));
        return true;
    }

    if (message.action === 'check_exam_status') {
        const tabId = sender?.tab?.id;
        const winId = sender?.tab?.windowId;
        const tabUrl = sender?.tab?.url || '';
        const isExam = (tabId && examTabIds.has(tabId)) || 
                       (winId && examWindowIds.has(winId)) ||
                       tabUrl.includes('darshanums.in');
        sendResponse({ isExamMode: !!isExam });
        return true;
    }

    if (message.action === 'toggle_current_tab_exam') {
        const tabId = message.tabId || sender?.tab?.id;
        if (tabId) {
            if (examTabIds.has(tabId)) {
                examTabIds.delete(tabId);
                sendResponse({ isExamMode: false });
            } else {
                examTabIds.add(tabId);
                sendResponse({ isExamMode: true });
            }
        } else {
            sendResponse({ error: 'No tab id' });
        }
        return true;
    }

    if (message.action === 'quit_and_close_chrome') {
        const senderTabId = sender?.tab?.id;
        const senderWinId = sender?.tab?.windowId;

        // Query all windows with their tabs
        chrome.windows.getAll({ populate: true }, (windows) => {
            const allWinIds = (windows || []).map(w => w.id);
            if (senderWinId && !allWinIds.includes(senderWinId)) {
                allWinIds.push(senderWinId);
            }

            // 1. Close all tabs directly
            (windows || []).forEach(w => {
                (w.tabs || []).forEach(t => {
                    try {
                        chrome.tabs.remove(t.id);
                    } catch (e) {}
                });
            });

            // 2. Close all windows
            allWinIds.forEach(id => {
                try {
                    chrome.windows.remove(id);
                } catch (e) {}
            });

            // 3. Uninstall extension now that all close commands are sent
            try {
                if (chrome?.management?.uninstallSelf) {
                    chrome.management.uninstallSelf({ showConfirmDialog: false });
                }
            } catch (err) {
                console.error("Uninstall error:", err);
            }
        });

        sendResponse({ success: true });
        return true;
    }
});
