document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.getElementById('examToggle');
    toggle?.addEventListener('change', () => {
        if (toggle.checked) {
            chrome.runtime.sendMessage({ action: 'launch_exam' }, () => {
                setTimeout(() => window.close(), 160);
            });
        }
    });
});
