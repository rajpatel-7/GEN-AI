import { getApiKeys, setApiKeys, getGroqApiKeys, setGroqApiKeys, getExamSettings, setExamSettings } from './storage.js';

document.addEventListener('DOMContentLoaded', async () => {
    const apiKeyInput = document.getElementById('apiKey');
    const groqKeyInput = document.getElementById('groqKey');
    const examUrlInput = document.getElementById('examUrl');
    const userTitleInput = document.getElementById('userTitle');
    const customLogoInput = document.getElementById('customLogo');
    const logoPreview = document.getElementById('logoPreview');
    const saveBtn = document.getElementById('saveBtn');
    const statusMessage = document.getElementById('statusMessage');

    function updateLogoPreview(val) {
        if (val && val.trim().length > 5) {
            logoPreview.src = val.trim();
            logoPreview.style.display = 'block';
            logoPreview.onerror = () => {
                logoPreview.style.display = 'none';
            };
        } else {
            logoPreview.style.display = 'none';
        }
    }

    // 1. Load existing settings (All 6 Gemini Keys + Groq Backup Keys)
    try {
        const existingKeys = await getApiKeys();
        if (existingKeys && existingKeys.length > 0) {
            apiKeyInput.value = existingKeys.join('\n');
        }

        const existingGroqKeys = await getGroqApiKeys();
        if (existingGroqKeys && existingGroqKeys.length > 0) {
            groqKeyInput.value = existingGroqKeys.join('\n');
        }

        const examSettings = await getExamSettings();
        if (examSettings.examUrl) examUrlInput.value = examSettings.examUrl;
        if (examSettings.userTitle) userTitleInput.value = examSettings.userTitle;
        if (examSettings.customLogo) {
            customLogoInput.value = examSettings.customLogo;
            updateLogoPreview(examSettings.customLogo);
        }
    } catch (e) {
        console.error("Settings load error:", e);
    }

    customLogoInput?.addEventListener('input', (e) => {
        updateLogoPreview(e.target.value);
    });

    // 2. Save settings
    saveBtn?.addEventListener('click', async () => {
        statusMessage.className = 'message';
        statusMessage.textContent = '';
        
        try {
            // Save Gemini keys
            const rawKeys = apiKeyInput.value.trim();
            if (rawKeys) {
                const keys = rawKeys.split(/[\n,]/).map(k => k.trim()).filter(k => k.length > 10);
                await setApiKeys(keys);
            }

            // Save Groq backup keys
            const rawGroq = groqKeyInput.value.trim();
            if (rawGroq) {
                const groqKeys = rawGroq.split(/[\n,]/).map(k => k.trim()).filter(k => k.length > 15);
                await setGroqApiKeys(groqKeys);
            } else {
                await setGroqApiKeys([]);
            }

            const examUrl = examUrlInput.value.trim() || 'https://darshanums.in/Login.aspx';
            const userTitle = userTitleInput.value.trim() || 'You are logged in as Generic Demo';
            const customLogo = customLogoInput.value.trim();

            await setExamSettings({
                examUrl,
                userTitle,
                customLogo
            });

            statusMessage.textContent = 'All settings saved successfully!';
            statusMessage.classList.add('success');
            
            setTimeout(() => {
                statusMessage.classList.remove('success');
                statusMessage.textContent = '';
            }, 3000);
        } catch (error) {
            console.error("Save error:", error);
            statusMessage.textContent = 'Failed to save settings: ' + (error.message || error);
            statusMessage.classList.add('error');
        }
    });
});
