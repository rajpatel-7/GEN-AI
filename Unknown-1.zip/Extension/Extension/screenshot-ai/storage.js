export async function getApiKeys() {
  const result = await chrome.storage.local.get(['geminiApiKeys']);
  if (result.geminiApiKeys && result.geminiApiKeys.length > 0) return result.geminiApiKeys;
  return [

  ];
}

export async function setApiKeys(keysArray) {
  await chrome.storage.local.set({ geminiApiKeys: keysArray });
}

export async function getApiKey() {
  const keys = await getApiKeys();
  return keys[0] || '';
}

export async function setApiKey(key) {
  const keys = key.includes(',') ? key.split(',').map(k => k.trim()).filter(Boolean) : [key];
  await setApiKeys(keys);
}
