import { analyzeScreenshot } from './gemini.js';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'start_capture') {
        const tabId = sender?.tab?.id;
        const windowId = sender?.tab?.windowId;
        
        async function runCaptureAndAnalyze() {
            try {
                const prompt = "You are an expert exam solver. Carefully analyze the image. Identify the question and all choices/options if present. Solve step-by-step internally to ensure 100% accuracy, then output ONLY the final answer clearly and concisely. For multiple choice questions, output the option letter and answer text (e.g., 'A) 42'). If multiple questions appear, put each answer on a new line. Do not include extra conversational text.";
                
                // Add tiny delay before capture to ensure UI finishes Darshan University paint frame
                await new Promise(r => setTimeout(r, 150));
                
                const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 70 });
                if (!dataUrl) {
                    throw new Error("Screen capture returned empty.");
                }
                
                const result = await analyzeScreenshot(dataUrl, prompt);
                const lines = result.text.split('\n').map(l => l.trim().replace(/[\*\_]/g, '')).filter(l => l);
                
                if (lines.length > 0) {
                    // Compute % limit. Assuming 1500 requests maximum limit per free key.
                    const maxRequests = result.activeKeysCount * 1500;
                    const percentUsed = ((result.totalUsageCount / maxRequests) * 100).toFixed(2);
                    lines.push(`Quota Used: ${percentUsed}%`);

                    chrome.tabs.sendMessage(tabId, { action: 'show_answers', lines: lines });
                } else {
                    throw new Error("Gemini returned blank answer.");
                }
            } catch (e) {
                console.error("Extension Error:", e);
                // Return short error summary
                const safeMessage = e.message ? e.message.substring(0, 45) : "Unknown crash";
                chrome.tabs.sendMessage(tabId, { action: 'show_error', text: safeMessage });
            }
        }
        
        runCaptureAndAnalyze();
        return true; 
    }
});
