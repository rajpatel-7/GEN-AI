// =====================================================
// browser-frame.js — "Safe Browser" fullscreen overlay
// Shift+A toggles the frame on/off
// =====================================================

let browserFrame = null;
let originalMarginTop = '';
let originalMarginBottom = '';
let originalOverflow = '';
let clockInterval = null;

function getPageTitle() {
    return document.title || window.location.hostname || 'New Tab';
}

// Exact SVG Icons mimicking the photos
const icons = {
    // Standard Chrome single horizontal line
    minimize: `<svg viewBox="0 0 10 10" width="12" height="12" fill="none" stroke="#444" stroke-width="1"><line x1="0" y1="5" x2="10" y2="5"/></svg>`,
    // Standard Chrome empty square
    maximize: `<svg viewBox="0 0 10 10" width="12" height="12" fill="none" stroke="#444" stroke-width="1"><rect x="0.5" y="0.5" width="9" height="9"/></svg>`,
    // Standard Chrome sharp X
    close: `<svg viewBox="0 0 10 10" width="12" height="12" fill="none" stroke="#444" stroke-width="1"><line x1="0" y1="0" x2="10" y2="10"/><line x1="10" y1="0" x2="0" y2="10"/></svg>`,
    // Custom arc that stops at the top, pointing right
    reload: `<svg viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="#222" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M 18.5 10 A 8 8 0 1 1 12 4" />
      <path d="M 8.5 1 L 12 4 L 8.5 7" />
    </svg>`,
    // Darker, bigger hamburger menu lines
    menu: `<svg viewBox="0 0 24 24" width="35" height="40" fill="none" stroke="#222" stroke-width="1.8" stroke-linecap="round"><path d="M3 12h18M3 6h18M3 18h18"/></svg>`,
    // Speaker for footer tray
    speaker: `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#222" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polygon points="10 5 5 9 1 9 1 15 5 15 10 19 10 5" fill="#222"></polygon>
      <path d="M14.5 9.5a3 3 0 0 1 0 5"></path>
      <path d="M17.5 7.5a7 7 0 0 1 0 9"></path>
      <path d="M20.5 5.5a11 11 0 0 1 0 13"></path>
    </svg>`,
    // Power button for footer tray
    power: `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="#222" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>`
};

// ---------- CSS Match Photo Perfectly ----------
function getFrameCSS() {
    return `
        /* Hide scrollbars completely while frame is active */
        ::-webkit-scrollbar {
            display: none !important;
            width: 0 !important;
            height: 0 !important;
        }

        #safe-browser-frame {
            position: fixed;
            top: 0; left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 2147483646;
            pointer-events: none;
            display: flex;
            flex-direction: column;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        /* ===== Title Bar (Top row) ===== */
        #sbf-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 28px; /* Slightly thinner */
            background: #ececec;
            border-bottom: 1px solid #dcdcdc; /* Faint separator */
            pointer-events: auto;
            padding-left: 20px; /* Moved much closer to the left edge like the photo */
            user-select: none;
        }

        #sbf-header-title {
            font-size: 12.5px;
            color: #444;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 70%;
            letter-spacing: 0.2px;
        }

        #sbf-header-controls {
            display: flex;
            align-items: center;
            height: 100%;
        }

        .sbf-win-btn {
            width: 48px;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
            cursor: default;
            pointer-events: none; /* disabled */
            /* opacity: 0.35;  Look definitively disabled */
        }

        /* ===== Toolbar (Second row) ===== */
        #sbf-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 48px; /* Taller, close to 1:2 ratio with header */
            background: #ececec; /* Same greyish background */
            border-bottom: 1px solid #dcdcdc;
            pointer-events: auto;
            padding: 0 10px 0 4px; /* Moved left edge to 4px to align perfectly */
            user-select: none;
        }

        .sbf-icon-btn {
            width: 44px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
            cursor: pointer;
            transition: background 0.15s;
        }

        /* ===== Transparent Body ===== */
        #sbf-content {
            flex: 1;
            pointer-events: none;
        }

        /* ===== Footer ===== */
        #sbf-footer {
            height: 48px; /* Matching toolbar height */
            background: #ececec; /* Greyish background */
            border-top: 1px solid #dcdcdc;
            pointer-events: auto;
            display: flex;
            align-items: center;
            justify-content: space-between; /* Space out left logo and right tray */
            padding-right: 14px;
            color: #222;
            user-select: none;
            box-sizing: border-box;
        }

        #sbf-footer-left {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 10px;
            border-bottom: 2.5px solid #0078D4; /* Windows active blue line */
            cursor: pointer;
            box-sizing: border-box; /* To ensure the border is within height */
            transition: background 0.15s;
        }
        #sbf-footer-left:hover {
            background: #dadada;
        }

        #sbf-footer-logo {
            height: 32px;
            width: auto;
        }

        #sbf-footer-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .sbf-footer-item {
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: default;
        }

        .sbf-footer-text {
            font-size: 14.5px;
            font-weight: 600;
        }

        .sbf-footer-time {
            display: flex;
            flex-direction: column;
            align-items: center;
            line-height: 1.15;
        }

        #sbf-clock-time {
            font-weight: 600;
            font-size: 13.5px;
        }

        #sbf-clock-date {
            font-weight: 400;
            font-size: 12.5px;
            color: #444;
        }

        /* ===== SEB Quit Confirmation Card ===== */
        #sbf-confirm-card {
            position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
            background: #f4f5f7; border: 1px solid #c0c0c0;
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
            width: 330px; border-radius: 10px; z-index: 2147483648;
            pointer-events: auto; font-family: 'Segoe UI', system-ui, sans-serif;
            display: none; padding-bottom: 24px;
        }
        #sbf-cc-header {
            display: flex; justify-content: space-between; padding: 10px 14px 0 14px;
            font-size: 12.5px; color: #555;
        }
        #sbf-cc-body {
            display: flex; align-items: center; padding: 25px 24px; gap: 14px;
            font-size: 16px; color: #111;
        }
        #sbf-cc-icon {
            background: #0078D4; color: white; border-radius: 50%;
            width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;
            font-weight: bold; font-size: 20px; flex-shrink: 0;
        }
        #sbf-cc-footer {
            display: flex; justify-content: center; gap: 12px;
        }
        #sbf-cc-footer button {
            padding: 5px 36px; border: 1px solid #aaa; background: transparent;
            border-radius: 6px; cursor: pointer; font-size: 14px; color: #222;
        }
        #sbf-cc-footer button:hover {
            border-color: #0078D4; background: rgba(0, 120, 212, 0.05);
        }
    `;
}

// ---------- Build the frame ----------
function createBrowserFrame() {
    if (document.getElementById('safe-browser-frame')) return;

    // Inject styles
    const style = document.createElement('style');
    style.id = 'safe-browser-frame-style';
    style.textContent = getFrameCSS();
    document.head.appendChild(style);

    // Container
    const frame = document.createElement('div');
    frame.id = 'safe-browser-frame';

    // ---- HEADER (Top row) ----
    const header = document.createElement('div');
    header.id = 'sbf-header';

    const title = document.createElement('span');
    title.id = 'sbf-header-title';
    title.textContent = getPageTitle();

    const controls = document.createElement('div');
    controls.id = 'sbf-header-controls';

    const btnMin = document.createElement('button');
    btnMin.className = 'sbf-win-btn';
    btnMin.innerHTML = icons.minimize;

    const btnMax = document.createElement('button');
    btnMax.className = 'sbf-win-btn';
    btnMax.innerHTML = icons.maximize;

    const btnClose = document.createElement('button');
    btnClose.className = 'sbf-win-btn';
    btnClose.innerHTML = icons.close;
    btnClose.style.opacity = '0.35'; // The only button that looks disabled

    controls.appendChild(btnMin);
    controls.appendChild(btnMax);
    controls.appendChild(btnClose);
    header.appendChild(title);
    header.appendChild(controls);

    // ---- TOOLBAR (Second row) ----
    const toolbar = document.createElement('div');
    toolbar.id = 'sbf-toolbar';

    const reloadBtn = document.createElement('button');
    reloadBtn.className = 'sbf-icon-btn';
    reloadBtn.title = 'Reload';
    reloadBtn.innerHTML = icons.reload;
    reloadBtn.addEventListener('click', () => {
        sessionStorage.setItem('safeBrowserActive', 'true');
        window.location.reload();
    });

    const menuBtn = document.createElement('button');
    menuBtn.className = 'sbf-icon-btn';
    menuBtn.title = 'Menu';
    menuBtn.innerHTML = icons.menu;

    toolbar.appendChild(reloadBtn);
    toolbar.appendChild(menuBtn);

    // ---- CONTENT & FOOTER ----
    const content = document.createElement('div');
    content.id = 'sbf-content';

    const footer = document.createElement('div');
    footer.id = 'sbf-footer';

    // Populate Left Logo
    const footerLeft = document.createElement('div');
    footerLeft.id = 'sbf-footer-left';
    
    const logoImg = document.createElement('img');
    logoImg.id = 'sbf-footer-logo';
    logoImg.src = chrome.runtime.getURL('logo.png');
    logoImg.alt = 'Logo';
    
    footerLeft.appendChild(logoImg);

    // Populate Right Area (fake system tray)
    const footerRight = document.createElement('div');
    footerRight.id = 'sbf-footer-right';

    const speakerIcon = document.createElement('div');
    speakerIcon.className = 'sbf-footer-item';
    speakerIcon.innerHTML = icons.speaker;
    
    const langText = document.createElement('div');
    langText.className = 'sbf-footer-item sbf-footer-text';
    langText.textContent = 'ENG';

    const timeBlock = document.createElement('div');
    timeBlock.className = 'sbf-footer-item sbf-footer-time';
    
    const timeDiv = document.createElement('div');
    timeDiv.id = 'sbf-clock-time';
    
    const dateDiv = document.createElement('div');
    dateDiv.id = 'sbf-clock-date';
    
    timeBlock.appendChild(timeDiv);
    timeBlock.appendChild(dateDiv);

    const powerIcon = document.createElement('div');
    powerIcon.className = 'sbf-footer-item';
    powerIcon.innerHTML = icons.power;
    powerIcon.style.cursor = 'pointer';

    footerRight.appendChild(speakerIcon);
    footerRight.appendChild(langText);
    footerRight.appendChild(timeBlock);
    footerRight.appendChild(powerIcon);
    
    footer.appendChild(footerLeft);
    footer.appendChild(footerRight);

    // Quit SEB Card HTML
    const confirmCard = document.createElement('div');
    confirmCard.id = 'sbf-confirm-card';
    confirmCard.innerHTML = `
        <div id="sbf-cc-header">
            <span>Quit?</span>
            <button id="sbf-cc-close" style="background:none;border:none;cursor:pointer;color:#999;font-size:16px;">×</button>
        </div>
        <div id="sbf-cc-body">
            <div id="sbf-cc-icon">?</div>
            <div>Do you want to quit SEB?</div>
        </div>
        <div id="sbf-cc-footer">
            <button id="sbf-confirm-quit">Yes</button>
            <button id="sbf-cancel-quit">No</button>
        </div>
    `;
    document.body.appendChild(confirmCard);

    powerIcon.addEventListener('click', () => {
        confirmCard.style.display = 'block';
    });

    confirmCard.querySelector('#sbf-cancel-quit').onclick = confirmCard.querySelector('#sbf-cc-close').onclick = () => {
        confirmCard.style.display = 'none';
    };
    confirmCard.querySelector('#sbf-confirm-quit').onclick = () => {
        chrome.runtime.sendMessage({ action: 'quit_chrome' });
    };

    // Assemble
    frame.appendChild(header);
    frame.appendChild(toolbar);
    frame.appendChild(content);
    frame.appendChild(footer);

    document.body.appendChild(frame);
    browserFrame = frame;

    // --- Dynamic Clock Clock Logic ---
    function updateClock() {
        if (!document.getElementById('sbf-clock-time')) return;
        const now = new Date();
        const hrs = String(now.getHours()).padStart(2, '0');
        const mins = String(now.getMinutes()).padStart(2, '0');
        const dd = String(now.getDate()).padStart(2, '0');
        
        // Ensure month matches standard calendar (1-12)
        const mm = String(now.getMonth() + 1).padStart(2, '0');
        const yyyy = now.getFullYear();
        
        document.getElementById('sbf-clock-time').textContent = hrs + ":" + mins;
        document.getElementById('sbf-clock-date').textContent = dd + "-" + mm + "-" + yyyy;
    }
    updateClock(); // Initial paint
    if (clockInterval) clearInterval(clockInterval);
    clockInterval = setInterval(updateClock, 5000);

    // --- PUSH WEBSITE DOWN & GO FULLSCREEN ---
    originalMarginTop = document.documentElement.style.marginTop;
    originalMarginBottom = document.documentElement.style.marginBottom;
    originalOverflow = document.documentElement.style.overflow;

    // Header (28px) + Toolbar (48px) = 76px top padding + 48px footer padding
    document.documentElement.style.setProperty('padding-top', '76px', 'important');
    document.documentElement.style.setProperty('padding-bottom', '48px', 'important');

    // Trust the background script to aggressively push the browser window into fullscreen,
    // bypassing the normal DOM user-activation-required restriction blocks on reload!
    chrome.runtime.sendMessage({ action: 'fullscreen_window' });
}

// ---------- Remove the frame ----------
function removeBrowserFrame() {
    const frame = document.getElementById('safe-browser-frame');
    if (frame) frame.remove();
    const style = document.getElementById('safe-browser-frame-style');
    if (style) style.remove();
    const card = document.getElementById('sbf-confirm-card');
    if (card) card.remove();
    
    browserFrame = null;

    if (clockInterval) {
        clearInterval(clockInterval);
        clockInterval = null;
    }

    // RESTORE WEBSITE POSITION & EXIT FULLSCREEN
    document.documentElement.style.paddingTop = originalMarginTop;
    document.documentElement.style.paddingBottom = originalMarginBottom;
    document.documentElement.style.overflow = originalOverflow;

    chrome.runtime.sendMessage({ action: 'exit_fullscreen_window' });

    sessionStorage.removeItem('safeBrowserActive');
}

// ---------- Toggle ----------
function toggleBrowserFrame() {
    if (browserFrame) {
        removeBrowserFrame();
    } else {
        sessionStorage.setItem('safeBrowserActive', 'true');
        createBrowserFrame();
    }
}

// Check auto-resume on reload
if (sessionStorage.getItem('safeBrowserActive') === 'true') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createBrowserFrame);
    } else {
        createBrowserFrame();
    }
}
