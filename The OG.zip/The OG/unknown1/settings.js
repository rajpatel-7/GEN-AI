import { getApiKeys, setApiKeys, getGroqApiKeys, setGroqApiKeys } from './storage.js';

document.addEventListener('DOMContentLoaded', async () => {
    const inputs = [
        document.getElementById('apiKey1'),
        document.getElementById('apiKey2'),
        document.getElementById('apiKey3'),
        document.getElementById('apiKey4'),
        document.getElementById('apiKey5'),
        document.getElementById('apiKey6'),
        document.getElementById('apiKey7'),
        document.getElementById('apiKey8'),
        document.getElementById('apiKey9'),
        document.getElementById('apiKey10')
    ];
    const groqInputs = [
        document.getElementById('groqKey1'),
        document.getElementById('groqKey2'),
        document.getElementById('groqKey3'),
        document.getElementById('groqKey4'),
        document.getElementById('groqKey5')
    ];
    const saveBtn = document.getElementById('saveBtn');
    const statusMessage = document.getElementById('statusMessage');

    // Load existing Gemini keys
    const existingKeys = await getApiKeys();
    if (existingKeys && Array.isArray(existingKeys)) {
        for (let i = 0; i < Math.min(existingKeys.length, 10); i++) {
            if (existingKeys[i]) inputs[i].value = existingKeys[i];
        }
    }

    // Load existing Groq keys
    const existingGroqKeys = await getGroqApiKeys();
    if (existingGroqKeys && Array.isArray(existingGroqKeys)) {
        for (let i = 0; i < Math.min(existingGroqKeys.length, 5); i++) {
            if (existingGroqKeys[i]) groqInputs[i].value = existingGroqKeys[i];
        }
    }

    saveBtn.addEventListener('click', async () => {
        statusMessage.className = 'message';
        statusMessage.textContent = '';

        // Gather all valid Gemini keys
        const keys = inputs.map(input => input.value.trim()).filter(key => key.length > 0);

        if (keys.length === 0) {
            statusMessage.textContent = 'Please enter at least one Gemini API key.';
            statusMessage.classList.add('error');
            return;
        }

        // Gather all valid Groq keys
        const groqKeys = groqInputs.map(input => input.value.trim()).filter(key => key.length > 0);

        try {
            await setApiKeys(keys);
            await setGroqApiKeys(groqKeys);
            statusMessage.textContent = 'Settings saved successfully!';
            statusMessage.classList.add('success');

            setTimeout(() => {
                statusMessage.classList.remove('success');
                statusMessage.textContent = '';
            }, 3000);
        } catch (error) {
            statusMessage.textContent = 'Failed to save settings.';
            statusMessage.classList.add('error');
        }
    });
});
