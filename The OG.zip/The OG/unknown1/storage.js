export async function getApiKeys() {
  const result = await chrome.storage.local.get(['geminiApiKeys']);
  if (result.geminiApiKeys) return result.geminiApiKeys;
  return [

  ];
}

export async function setApiKeys(keysArray) {
  await chrome.storage.local.set({ geminiApiKeys: keysArray });
}

export async function getGroqApiKeys() {
  const result = await chrome.storage.local.get(['groqApiKeys']);
  if (result.groqApiKeys && result.groqApiKeys.length > 0) return result.groqApiKeys;
  return [
    ,
    // 'YOUR_GROQ_KEY_2_HERE',
  ];
}

export async function setGroqApiKeys(keysArray) {
  await chrome.storage.local.set({ groqApiKeys: keysArray });
}
