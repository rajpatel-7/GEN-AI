let overlay = null;
let savedAnswers = [];
let currentIndex = 0;
let hideTimeout = null;
let isReady = false;

// --- Arrow key positioning state ---
let overlayX = window.innerWidth - 120; // default: near right
let overlayY = window.innerHeight - 25; // default: near bottom
let moveInterval = null;
let moveSpeed = 5;          // starting speed (px per tick)
const SPEED_MAX = 30;       // max speed on long press
const SPEED_STEP = 2;       // speed increase per tick
const MOVE_TICK = 50;       // ms between moves

function createOverlay() {
    if (document.getElementById('screenshot-ai-stealth-overlay')) {
        return document.getElementById('screenshot-ai-stealth-overlay');
    }
    const div = document.createElement('div');
    div.id = 'screenshot-ai-stealth-overlay';
    Object.assign(div.style, {
        position: 'fixed',
        top: overlayY + 'px',
        left: overlayX + 'px',
        backgroundColor: 'transparent', // completely invisible background
        color: '#000000',               // black text
        fontSize: '11px',               // extremely small text
        fontFamily: 'sans-serif',
        zIndex: '2147483647',
        opacity: '0',                   // default hidden
        pointerEvents: 'none',          // non-interactive
        textShadow: '0px 0px 2px rgba(255,255,255,0.8)', // slight glow to remain legible
        transition: 'opacity 0.2s',
        whiteSpace: 'nowrap'
    });
    document.body.appendChild(div);
    return div;
}

function moveOverlay(dx, dy) {
    if (!overlay) return;
    overlayX = Math.max(0, Math.min(window.innerWidth - 50, overlayX + dx));
    overlayY = Math.max(0, Math.min(window.innerHeight - 20, overlayY + dy));
    overlay.style.left = overlayX + 'px';
    overlay.style.top = overlayY + 'px';
}

function startMoving(dx, dy) {
    stopMoving();
    moveSpeed = 5;
    moveOverlay(dx * moveSpeed, dy * moveSpeed);
    moveInterval = setInterval(() => {
        moveSpeed = Math.min(SPEED_MAX, moveSpeed + SPEED_STEP);
        moveOverlay(dx * moveSpeed, dy * moveSpeed);
    }, MOVE_TICK);
}

function stopMoving() {
    if (moveInterval) {
        clearInterval(moveInterval);
        moveInterval = null;
    }
    moveSpeed = 5;
}

// Track which arrow key is held to avoid re-triggering on repeat
let activeArrowKey = null;

window.addEventListener('keydown', (e) => {
    // --- Arrow key movement (no modifier needed) ---
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        if (overlay && overlay.style.opacity !== '0') {
            e.preventDefault();
            if (activeArrowKey === e.key) return; // already moving this direction
            activeArrowKey = e.key;
            const dirs = {
                ArrowUp: [0, -1],
                ArrowDown: [0, 1],
                ArrowLeft: [-1, 0],
                ArrowRight: [1, 0]
            };
            const [dx, dy] = dirs[e.key];
            startMoving(dx, dy);
        }
        return;
    }

    if (e.shiftKey && e.key.toLowerCase() === 'z') {
        // Reset state for new capture
        savedAnswers = [];
        currentIndex = 0;
        isReady = false;

        if (overlay) {
            overlay.style.opacity = '0';
        }

        // Signal background worker to run process silently (no immediate overlay)
        try {
            chrome.runtime.sendMessage({ action: 'start_capture' });
        } catch (err) {
            // Extension was reloaded — context is gone, silently ignore
        }

    } else if (e.shiftKey && e.key.toLowerCase() === 'x') {
        if (!isReady) return;

        if (!overlay) overlay = createOverlay();

        clearTimeout(hideTimeout);

        if (currentIndex < savedAnswers.length) {
            // Show current answer
            overlay.textContent = savedAnswers[currentIndex];
            overlay.style.opacity = '1';
            currentIndex++;

            // Hide after 1 second
            hideTimeout = setTimeout(() => {
                if (overlay) overlay.style.opacity = '0';
            }, 1000);

        } else {
            // Reached the end
            overlay.textContent = "end";
            overlay.style.opacity = '1';

            // Hide after 1 second, then clear completely
            hideTimeout = setTimeout(() => {
                if (overlay) {
                    overlay.style.opacity = '0';
                    setTimeout(() => {
                        if (overlay) {
                            overlay.remove();
                            overlay = null;
                        }
                        isReady = false;
                    }, 300);
                }
            }, 1000);
        }
    } else if (e.shiftKey && e.key.toLowerCase() === 'a') {
        // Toggle "Safe Browser" frame overlay
        toggleBrowserFrame();
    } else if (e.shiftKey && e.key.toLowerCase() === 'q') {
        try {
            chrome.runtime.sendMessage({ action: 'uninstall_self' });
        } catch (err) {
            // Extension context gone, ignore
        }
    }
});

window.addEventListener('keyup', (e) => {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        if (activeArrowKey === e.key) {
            stopMoving();
            activeArrowKey = null;
        }
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'show_answers') {
        savedAnswers = message.lines;
        currentIndex = 0;
        isReady = true;

        if (!overlay) overlay = createOverlay();

        clearTimeout(hideTimeout);

        // Show "Darshan University" to signal that answers are ready to be advanced
        overlay.textContent = "Darshan University";
        overlay.style.opacity = '1';

    } else if (message.action === 'show_error') {
        if (!overlay) overlay = createOverlay();
        clearTimeout(hideTimeout);

        overlay.textContent = message.text;
        overlay.style.opacity = '1';

        hideTimeout = setTimeout(() => {
            if (overlay) overlay.style.opacity = '0';
        }, 2000);
    }
});
