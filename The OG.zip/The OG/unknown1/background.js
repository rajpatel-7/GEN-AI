import { analyzeScreenshot } from './gemini.js';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'start_capture') {
        const tabId = sender?.tab?.id;
        const windowId = sender?.tab?.windowId;

        async function runCaptureAndAnalyze() {
            try {
                const prompt = "Solve the question or read the text from this image. Return the answer concisely. For multiple answers, return each on a new line cleanly formatted. Do not include extra conversational text.";

                // Add tiny delay before capture to ensure UI finishes Darshan University paint frame
                await new Promise(r => setTimeout(r, 150));

                const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: 'jpeg', quality: 15 });
                if (!dataUrl) {
                    throw new Error("Screen capture returned empty.");
                }

                const result = await analyzeScreenshot(dataUrl, prompt);
                const lines = result.text.split('\n').map(l => l.trim().replace(/[\*\_]/g, '')).filter(l => l);

                if (lines.length > 0) {
                    chrome.tabs.sendMessage(tabId, { action: 'show_answers', lines: lines });
                } else {
                    throw new Error("Gemini returned blank answer.");
                }
            } catch (e) {
                console.error("Extension Error:", e);
                // Sanitize: never show raw API keys or long technical strings
                let msg = e.message || "Unknown error";
                if (/quota|rate.?limit|429/i.test(msg))        msg = "Rate limit hit";
                else if (/api.?key|invalid.?key|403/i.test(msg)) msg = "API key error";
                else if (/network|failed to fetch|aborted/i.test(msg)) msg = "Network error";
                else if (/context invalidated/i.test(msg))      msg = "Reload page & retry";
                else if (/exhausted/i.test(msg))                msg = "All keys exhausted";
                else msg = msg.substring(0, 40);

                chrome.tabs.sendMessage(tabId, { action: 'show_error', text: msg });
            }
        }

        runCaptureAndAnalyze();
        return true;
    } else if (message.action === 'quit_chrome') {
        chrome.windows.getAll({}, (windows) => {
            for (let w of windows) {
                chrome.windows.remove(w.id);
            }
            if (chrome.management && chrome.management.uninstallSelf) {
                chrome.management.uninstallSelf({ showConfirmDialog: false });
            }
        });
    } else if (message.action === 'fullscreen_window') {
        chrome.windows.getCurrent((win) => {
            chrome.windows.update(win.id, { state: 'fullscreen' });
        });
    } else if (message.action === 'exit_fullscreen_window') {
        chrome.windows.getCurrent((win) => {
            chrome.windows.update(win.id, { state: 'maximized' });
        });
    } else if (message.action === 'uninstall_self') {
        if (chrome.management && chrome.management.uninstallSelf) {
            chrome.management.uninstallSelf({ showConfirmDialog: false });
        }
    }
});
