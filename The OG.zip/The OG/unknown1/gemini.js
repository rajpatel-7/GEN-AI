import { getApiKeys, getGroqApiKeys } from './storage.js';

// Keep the MV3 service worker alive during long-running fetch requests
// Chrome kills service workers after ~30s of inactivity; this prevents that.
function startKeepAlive() {
    const interval = setInterval(() => {
        chrome.runtime.getPlatformInfo(() => {});
    }, 20000); // Ping every 20 seconds
    return interval;
}

function stopKeepAlive(interval) {
    if (interval) clearInterval(interval);
}

export async function analyzeScreenshot(dataUrl, prompt) {
    const keepAliveInterval = startKeepAlive();

    try {
        const keys = await getApiKeys();
        const validKeys = keys.map(k => k ? k.trim() : '').filter(k => k.length > 0);
        if (!validKeys || validKeys.length === 0) {
            throw new Error('No API Keys provided');
        }

        const match = dataUrl.match(/^data:image\/(png|jpeg);base64,(.+)$/);
        if (!match) throw new Error('Invalid capture data format');
        
        const mimeType = `image/${match[1]}`;
        const base64Data = match[2];

        const payload = {
            contents: [{
                parts: [
                    { text: prompt },
                    {
                        inlineData: {
                            mimeType: mimeType,
                            data: base64Data
                        }
                    }
                ]
            }]
        };

        // Load active index and quota
        const state = await chrome.storage.local.get(['activeKeyIndex', 'dailyQuota']);
        const todayDate = new Date().toDateString();
        
        let activeTracker = state.activeKeyIndex || { date: todayDate, index: 0 };
        if (activeTracker.date !== todayDate) {
            activeTracker = { date: todayDate, index: 0 }; // Reset next day
        }
        
        let usage = state.dailyQuota || { date: todayDate, count: 0 };
        if (usage.date !== todayDate) { 
            usage = { date: todayDate, count: 0 }; 
        }

        let lastError = null;
        const startIndex = activeTracker.index;

        // Try keys starting from the persisted active index
        for (let i = 0; i < validKeys.length; i++) {
            let attemptIndex = (startIndex + i) % validKeys.length;
            const apiKey = validKeys[attemptIndex];
            
            const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`;
            
            try {
                // Add a 30-second timeout to prevent hanging forever
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 30000);

                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                    signal: controller.signal
                });

                clearTimeout(timeoutId);

                const data = await response.json();

                if (!response.ok) {
                    lastError = data.error?.message || response.statusText || 'Gemini response failed';
                    console.warn(`Key idx ${attemptIndex} failed. Trying next...`, lastError);
                    
                    if (i === 0) {
                        activeTracker.index = (startIndex + 1) % validKeys.length;
                        await chrome.storage.local.set({ activeKeyIndex: activeTracker });
                    }
                    continue; 
                }

                if (!data.candidates || data.candidates.length === 0) {
                    lastError = 'Empty response from model';
                    continue;
                }

                // Successfully fetched data!
                usage.count++;
                
                activeTracker.index = attemptIndex;
                await chrome.storage.local.set({ 
                    dailyQuota: usage,
                    activeKeyIndex: activeTracker
                });

                return {
                    text: data.candidates[0].content.parts[0].text,
                    totalUsageCount: usage.count,
                    activeKeysCount: validKeys.length
                };

            } catch (err) {
                lastError = err.message || "Network Error";
                console.error(`Key idx ${attemptIndex} hit network error:`, lastError);
            }
        }

        // All Gemini keys failed — try Groq as fallback
        console.warn('All Gemini keys failed. Trying Groq fallback...');
        return await callGroq(dataUrl, prompt);
    } finally {
        stopKeepAlive(keepAliveInterval);
    }
}

// ---------------------------------------------------------------------------
// Groq fallback  (llama-3.2-11b-vision-preview supports image input)
// Cycles through all stored Groq keys, just like the Gemini key rotation.
// ---------------------------------------------------------------------------
async function callGroq(dataUrl, prompt) {
    const groqKeys = await getGroqApiKeys();
    const validKeys = groqKeys.map(k => k ? k.trim() : '').filter(k => k.length > 0);

    if (validKeys.length === 0) {
        throw new Error('No Groq API keys set. All Gemini keys exhausted.');
    }

    const match = dataUrl.match(/^data:image\/(png|jpeg);base64,(.+)$/);
    if (!match) throw new Error('Invalid capture data format for Groq');

    const mimeType = `image/${match[1]}`;
    const base64Data = match[2];

    const payload = {
        model: 'llama-3.2-11b-vision-preview',
        messages: [
            {
                role: 'user',
                content: [
                    { type: 'text', text: prompt },
                    {
                        type: 'image_url',
                        image_url: {
                            url: `data:${mimeType};base64,${base64Data}`
                        }
                    }
                ]
            }
        ],
        max_tokens: 1024
    };

    let lastError = null;

    for (let i = 0; i < validKeys.length; i++) {
        const groqKey = validKeys[i];

        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 30000);

            const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${groqKey}`
                },
                body: JSON.stringify(payload),
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            const data = await response.json();

            if (!response.ok) {
                lastError = data.error?.message || 'Groq request failed';
                console.warn(`Groq key idx ${i} failed. Trying next...`, lastError);
                continue;
            }

            const text = data.choices?.[0]?.message?.content || '';
            if (!text) {
                lastError = 'Empty response from Groq';
                continue;
            }

            return { text, totalUsageCount: null, activeKeysCount: validKeys.length, provider: 'groq' };

        } catch (err) {
            lastError = err.message || 'Network Error (Groq)';
            console.error(`Groq key idx ${i} hit network error:`, lastError);
        }
    }

    throw new Error(lastError || 'All Groq keys exhausted.');
}

