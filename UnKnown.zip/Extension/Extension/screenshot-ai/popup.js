import { getApiKey } from './storage.js';
import { analyzeScreenshot } from './gemini.js';

document.addEventListener('DOMContentLoaded', async () => {
    const errorText = document.getElementById('errorText');

    function showError(message) {
        if(errorText) {
            errorText.textContent = message;
            errorText.classList.remove('hidden');
        }
    }

    async function processCapture() {
        const prompt = "Solve the question or read the text from this image. Return the answer concisely. For multiple answers, return each on a new line cleanly formatted. Do not include extra conversational text.";
        
        try {
            const apiKey = await getApiKey();
            if (!apiKey) {
                showError('No API Key');
                return;
            }

            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tabs.length === 0) return;

            const activeTab = tabs[0];
            
            if (activeTab.url && (activeTab.url.startsWith('chrome://') || activeTab.url.startsWith('edge://') || activeTab.url.startsWith('about:') || activeTab.url.startsWith('https://chrome.google.com/webstore'))) {
                showError('Restricted Page');
                return;
            }

            // 1. Capture extremely fast with quality 15 (creates a tiny file size that uploads in milliseconds!)
            const dataUrl = await chrome.tabs.captureVisibleTab(activeTab.windowId, { format: 'jpeg', quality: 15 });
            if (!dataUrl) {
                showError('Failed to capture');
                return;
            }

            // 2. Immediately inject "Darshan University" to show it's working instantly
            await chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: () => {
                    let overlay = document.getElementById('screenshot-ai-stealth-overlay');
                    if (!overlay) {
                        overlay = document.createElement('div');
                        overlay.id = 'screenshot-ai-stealth-overlay';
                        Object.assign(overlay.style, {
                            position: 'fixed',
                            bottom: '5px',
                            right: '15px',
                            backgroundColor: 'transparent',
                            color: '#000000',
                            fontSize: '11px',
                            fontFamily: 'sans-serif',
                            zIndex: '2147483647',
                            opacity: '1',
                            pointerEvents: 'none',
                            textShadow: '0px 0px 2px rgba(255,255,255,0.8)',
                            transition: 'opacity 0.3s'
                        });
                        document.body.appendChild(overlay);
                    }
                    overlay.style.opacity = '1';
                    overlay.textContent = "Darshan University";
                }
            });

            // 3. Make fetch call (which is now wildly faster due to the image size)
            const resultText = await analyzeScreenshot(dataUrl, prompt);
            
            const lines = resultText.split('\n')
                                    .map(l => l.trim().replace(/[\*\_]/g, ''))
                                    .filter(l => l);

            if (lines.length > 0) {
                // 4. Update the injected UI sequence
                await chrome.scripting.executeScript({
                    target: { tabId: activeTab.id },
                    func: (answers) => {
                        const overlay = document.getElementById('screenshot-ai-stealth-overlay');
                        if (!overlay) return;

                        let i = 0;
                        function showNext() {
                            if (i >= answers.length) {
                                overlay.style.opacity = '0';
                                setTimeout(() => overlay.remove(), 300);
                                return;
                            }
                            overlay.textContent = answers[i];
                            overlay.style.opacity = '1';
                            
                            setTimeout(() => {
                                overlay.style.opacity = '0';
                                setTimeout(() => {
                                    i++;
                                    showNext();
                                }, 400); 
                            }, 1000); 
                        }
                        
                        // Begin crossfade from "Darshan University" into the answers instantly!
                        overlay.style.opacity = '0';
                        setTimeout(showNext, 300);
                    },
                    args: [lines]
                });
                
                window.close(); // Exit popup stealthily
            } else {
                showError("No answer");
            }
        } catch (e) {
            console.error(e);
            showError(e.message || "Error");
        }
    }

    // Auto-run instantly
    processCapture();
});
