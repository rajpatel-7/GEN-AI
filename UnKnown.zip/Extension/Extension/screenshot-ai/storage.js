export async function getApiKeys() {
  const result = await chrome.storage.local.get(['geminiApiKeys']);
  if (result.geminiApiKeys) return result.geminiApiKeys;
  return [
    'AQ.Ab8RN6ITpXfXIdKeJ1ALfbcboe_h4G8v8qGr_27GEp8aBZvERA',
    'AQ.Ab8RN6Ifqs4XIJRXVJTlebetIGUzr2Lq65C9HLpSCvjnVwvIHg'
  ];
}

export async function setApiKeys(keysArray) {
  await chrome.storage.local.set({ geminiApiKeys: keysArray });
}
