# Screenshot AI

A Chrome Extension powered by Manifest V3 that captures the visible tab, sends the screenshot to the Gemini Vision API alongside a custom user prompt, and displays the response directly in the extension popup.

## Features
- **Capture on Demand**: Captures the currently visible viewport *only* when you click the "Capture & Ask Gemini" button.
- **Custom Prompts**: Allows asking specific questions about the screen content.
- **Markdown Support**: Renders Gemini's markdown response cleanly.
- **Privacy Conscious**: Screenshots are never saved to disk and are strictly stored in memory for the duration of the API request.

## Installation for Development

1. Open a new tab in Google Chrome and navigate to `chrome://extensions`.
2. Turn on **Developer Mode** using the toggle switch in the top right corner.
3. Click the **Load unpacked** button in the top left.
4. Select the `screenshot-ai` folder (the same directory containing this `README.md`).

## Gemini API Setup

To use this extension, you will need a Gemini API Key:

1. Visit [Google AI Studio](https://aistudio.google.com/) and sign in with your Google account.
2. Click **Get API key** and generate a new key.
3. Click the **Extension Icon** in your Chrome toolbar.
4. Click the gear icon (⚙️) to open **Settings**.
5. Paste your API key into the input field and click **Save Key**.

**Security Note:**
The API key is stored locally in Chrome (`chrome.storage.local`) and is NOT synced to the cloud. Do **not** commit your personal API key into source control (GitHub, etc.). This extension is intended for personal/developer use. For a public release on the Chrome Web Store intended for multiple users, you must remove client-side API key configuration and route requests through a protected backend proxy to protect API quotas and billing.

## Usage

1. Open any typical webpage where you have a question.
2. Click the **Screenshot AI** extension icon in your Chrome toolbar.
3. Replace the default text ("Analyze this screenshot and answer what you see.") with your custom question if desired.
4. Click **📸 Capture & Ask Gemini**.
5. Wait a few seconds for Gemini to analyze the screenshot, and read the answer!

## Permissions Explained

This extension uses Manifest V3 and requests the absolute minimum permissions required to function:
- `activeTab`: Used to temporarily gain access to capture the visible viewport (`chrome.tabs.captureVisibleTab`) of your current tab *only* when the extension popup is opened and interacted with.
- `storage`: Required to securely store your Gemini API key locally on your device.
- `host_permissions: https://generativelanguage.googleapis.com/*`: Required to fetch results directly from the Gemini APIs.

## Chrome Web Store Preparation

Before publishing this extension to the Chrome Web Store, the following must be verified:
- **Backend Architecture**: Do not allow users to inject their own keys for a commercial product; instead, route through a secure environment variable on a proxy server.
- **Icon Assets**: Replace placeholder `icon16.png`, `icon32.png`, `icon48.png`, and `icon128.png` with official, polished branding assets.
- **Privacy Policy**: A comprehensive privacy policy stating clear data compliance boundaries regarding transmitting screen captures must be provided.

## Disclaimer

Chrome naturally restricts capturing certain pages internally (such as `chrome://` extensions or the Chrome Web Store) for security reasons. Screenshot AI respects these constraints and handles them gracefully.
