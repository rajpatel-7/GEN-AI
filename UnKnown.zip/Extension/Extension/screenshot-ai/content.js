let overlay = null;

function createOverlay() {
    if (document.getElementById('screenshot-ai-stealth-overlay')) {
        return document.getElementById('screenshot-ai-stealth-overlay');
    }
    const div = document.createElement('div');
    div.id = 'screenshot-ai-stealth-overlay';
    Object.assign(div.style, {
        position: 'fixed',
        bottom: '5px',
        right: '15px',
        backgroundColor: 'transparent',
        color: '#000000',
        fontSize: '11px',
        fontFamily: 'sans-serif',
        zIndex: '2147483647',
        opacity: '0',
        pointerEvents: 'none',
        textShadow: '0px 0px 2px rgba(255,255,255,0.8)',
        transition: 'opacity 0.3s'
    });
    document.body.appendChild(div);
    return div;
}

window.addEventListener('keydown', (e) => {
    // Only trigger if Shift + Z is pressed exactly
    if (e.shiftKey && e.key.toLowerCase() === 'z') {
        
        overlay = createOverlay();
        overlay.style.opacity = '1';
        overlay.textContent = "Darshan University";
        
        // Signal background worker to run process silently
        chrome.runtime.sendMessage({ action: 'start_capture' });
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'show_answers') {
        const answers = message.lines;
        if (!overlay) overlay = createOverlay();
        
        let i = 0;
        function showNext() {
            if (i >= answers.length) {
                overlay.style.opacity = '0';
                setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 300);
                return;
            }
            overlay.textContent = answers[i];
            overlay.style.opacity = '1';
            
            setTimeout(() => {
                overlay.style.opacity = '0';
                setTimeout(() => {
                    i++;
                    showNext();
                }, 400); 
            }, 1000); 
        }
        
        overlay.style.opacity = '0';
        setTimeout(showNext, 300);
        
    } else if (message.action === 'show_error') {
        if (!overlay) overlay = createOverlay();
        overlay.textContent = message.text;
        overlay.style.opacity = '1';
        setTimeout(() => {
            overlay.style.opacity = '0';
            setTimeout(() => { if(overlay) overlay.remove(); overlay = null; }, 300);
        }, 2000);
    }
});
