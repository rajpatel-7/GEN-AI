import { getApiKeys } from './storage.js';

export async function analyzeScreenshot(dataUrl, prompt) {
    const keys = await getApiKeys();
    if (!keys || keys.length === 0) {
        throw new Error('No API Keys provided');
    }

    const match = dataUrl.match(/^data:image\/(png|jpeg);base64,(.+)$/);
    if (!match) throw new Error('Invalid capture data format');
    
    const mimeType = `image/${match[1]}`;
    const base64Data = match[2];

    const payload = {
        contents: [{
            parts: [
                { text: prompt },
                {
                    inlineData: {
                        mimeType: mimeType,
                        data: base64Data
                    }
                }
            ]
        }]
    };

    let lastError = null;

    // Iterate through all provided API keys. If one fails (e.g. rate limit), try the next securely.
    for (let i = 0; i < keys.length; i++) {
        const apiKey = keys[i];
        if (!apiKey || apiKey.includes('SECOND_API_KEY')) continue; // Skip placeholders
        
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${apiKey}`;
        
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const data = await response.json();

            if (!response.ok) {
                lastError = data.error?.message || response.statusText || 'Gemini response failed';
                console.warn(`Key ${i} failed. Trying next key if available...`, lastError);
                continue; // Move on to next key
            }

            if (!data.candidates || data.candidates.length === 0) {
                lastError = 'Empty response from model';
                continue;
            }

            // Successfully fetched data. Track usage.
            // A free Gemini API key grants 1500 requests per day limits.
            const stats = await chrome.storage.local.get(['dailyQuota']);
            const todayDate = new Date().toDateString();
            let usage = stats.dailyQuota || { date: todayDate, count: 0 };
            
            // Reset counter naturally if day changes
            if (usage.date !== todayDate) { 
                usage = { date: todayDate, count: 0 }; 
            }
            usage.count++;
            await chrome.storage.local.set({ dailyQuota: usage });

            return {
                text: data.candidates[0].content.parts[0].text,
                totalUsageCount: usage.count,
                activeKeysCount: keys.filter(k => k && !k.includes('SECOND_API_KEY')).length
            };

        } catch (err) {
            lastError = err.message || "Network Error";
            console.error(`Key ${i} hit crash:`, lastError);
        }
    }

    throw new Error(lastError || 'All API Keys Exhausted or Failed.');
}
