import { getApiKey, setApiKey } from './storage.js';

document.addEventListener('DOMContentLoaded', async () => {
    const apiKeyInput = document.getElementById('apiKey');
    const saveBtn = document.getElementById('saveBtn');
    const statusMessage = document.getElementById('statusMessage');

    // Load existing key
    const existingKey = await getApiKey();
    if (existingKey) {
        apiKeyInput.value = existingKey;
    }

    saveBtn.addEventListener('click', async () => {
        const key = apiKeyInput.value.trim();
        statusMessage.className = 'message';
        statusMessage.textContent = '';
        
        if (!key) {
            statusMessage.textContent = 'Please enter an API key.';
            statusMessage.classList.add('error');
            return;
        }

        try {
            await setApiKey(key);
            statusMessage.textContent = 'Settings saved successfully!';
            statusMessage.classList.add('success');
            
            // Hide success message after 3 seconds
            setTimeout(() => {
                statusMessage.classList.remove('success');
                statusMessage.textContent = '';
            }, 3000);
        } catch (error) {
            statusMessage.textContent = 'Failed to save settings.';
            statusMessage.classList.add('error');
        }
    });
});
